package Near;

public class ReserveBean {

	private int reserveno;
	private int nearno;
	private String username;
	private String nearname;
	private int reserveterm;
	private String reserveday;
	private int usenum;
	private String img;
	
	
	public int getReserveno() {
		return reserveno;
	}
	public void setReserveno(int reserveno) {
		this.reserveno = reserveno;
	}

	public int getNearno() {
		return nearno;
	}
	public void setNearno(int nearno) {
		this.nearno = nearno;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getNearname() {
		return nearname;
	}
	public void setNearname(String nearname) {
		this.nearname = nearname;
	}
	public int getReserveterm() {
		return reserveterm;
	}
	public void setReserveterm(int reserveterm) {
		this.reserveterm = reserveterm;
	}
	
	public String getReserveday() {
		return reserveday;
	}
	public void setReserveday(String reserveday) {
		this.reserveday = reserveday;
	}
	public int getUsenum() {
		return usenum;
	}
	public void setUsenum(int usenum) {
		this.usenum = usenum;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	
	
}
