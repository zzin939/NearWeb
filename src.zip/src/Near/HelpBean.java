package Near;

import java.util.Date;

public class HelpBean {
	
	private int helpno;
	private String username;
	private String email;
	private String helptitle;
	private Date uploaddate;
	private String helpcontent;
	
	
	public int getHelpno() {
		return helpno;
	}
	public void setHelpno(int helpno) {
		this.helpno = helpno;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getHelptitle() {
		return helptitle;
	}
	public void setHelptitle(String helptitle) {
		this.helptitle = helptitle;
	}
	public Date getUploaddate() {
		return uploaddate;
	}
	public void setUploaddate(Date uploaddate) {
		this.uploaddate = uploaddate;
	}
	public String getHelpcontent() {
		return helpcontent;
	}
	public void setHelpcontent(String helpcontent) {
		this.helpcontent = helpcontent;
	}
	
	
}
