package Near;

public class NearListBean {

	
	private int nearno;
	private String nearname;
	private String nearstate;
	private String nearaddress;
	private int usepeople;
	private int price;
	private String img;
	private String nearinfo;
	private String hostinfo;
	
	
	public int getNearno() {
		return nearno;
	}
	public void setNearno(int nearno) {
		this.nearno = nearno;
	}
	public String getNearname() {
		return nearname;
	}
	public void setNearname(String nearname) {
		this.nearname = nearname;
	}
	public String getNearstate() {
		return nearstate;
	}
	public void setNearstate(String nearstate) {
		this.nearstate = nearstate;
	}
	public String getNearaddress() {
		return nearaddress;
	}
	public void setNearaddress(String nearaddress) {
		this.nearaddress = nearaddress;
	}
	public int getUsepeople() {
		return usepeople;
	}
	public void setUsepeople(int usepeople) {
		this.usepeople = usepeople;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public String getNearinfo() {
		return nearinfo;
	}
	public void setNearinfo(String nearinfo) {
		this.nearinfo = nearinfo;
	}
	public String getHostinfo() {
		return hostinfo;
	}
	public void setHostinfo(String hostinfo) {
		this.hostinfo = hostinfo;
	}
	
	
	

}

