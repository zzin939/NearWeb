package Near;

public class UserViewBean {


	private String userid;
	private int reserveno;
	private String username;
	private String nearname;
	private int reserveterm;
	private String reserveday;
	private int usenum;
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public int getReserveno() {
		return reserveno;
	}
	public void setReserveno(int reserveno) {
		this.reserveno = reserveno;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getNearname() {
		return nearname;
	}
	public void setNearname(String nearname) {
		this.nearname = nearname;
	}
	public int getReserveterm() {
		return reserveterm;
	}
	public void setReserveterm(int reserveterm) {
		this.reserveterm = reserveterm;
	}
	public String getReserveday() {
		return reserveday;
	}
	public void setReserveday(String reserveday) {
		this.reserveday = reserveday;
	}
	public int getUsenum() {
		return usenum;
	}
	public void setUsenum(int usenum) {
		this.usenum = usenum;
	}
		
						
	
}
